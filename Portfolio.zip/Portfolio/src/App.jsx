import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Header from "./Components/Header";
import Home from "./Components/Home";
import About from "./Components/About";
import Projects from "./Components/Projects";
import Contact from "./Components/Contact";
import "./App.css";
import Quiz from "./Components/Quiz/Quiz";
import ThemeTg from "./Components/ThemeTg/Switcher";

const App = () => {
  return (
    <Router>
      <Header />
      <h1 style={{ alignItems: "center" }}>My Portfolio</h1>

      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/projects" element={<Projects />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/quiz" element={<Quiz />} />
      </Routes>
      <ThemeTg />
    </Router>
  );
};

export default App;
