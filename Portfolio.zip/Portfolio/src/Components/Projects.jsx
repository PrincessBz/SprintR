import React from "react";
import "../Projects.css";

const Projects = () => {
  const projects = [
    {
      title: "Antique Shop Naija",
      description:
        "An e-commerce project featuring shopping carts, real-time cart calculations, and a checkout process. This project reflects my ability to implement key e-commerce functionality.",
      techStack: "React, JavaScript, CSS",
      liveLink: "#", 
      codeLink: "#", 
    },
    {
      title: "Portfolio Website",
      description:
        "My personal portfolio website, designed to showcase my skills and projects as I progress in my software development journey.",
      techStack: "React, CSS",
      liveLink: "#", 
      codeLink: "#", 
    },
  ];

  return (
    <section className="projects-section">
      <div className="projects-container">
        <h2>My Projects</h2>
        <div className="projects-list">
          {projects.map((project, index) => (
            <div className="project-card" key={index}>
              <h3>{project.title}</h3>
              <p>{project.description}</p>
              <p>
                <strong>Tech Stack:</strong> {project.techStack}
              </p>
              <div className="project-links">
                <a
                  href={project.liveLink}
                  className="btn"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  View Live
                </a>
                <a
                  href={project.codeLink}
                  className="btn"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  View Code
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
export default Projects;
