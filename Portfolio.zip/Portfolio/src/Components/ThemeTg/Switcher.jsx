import { useState } from "react";

import "./switcher.css";

const Switcher = () => {
  const [darkMode, setDarkMode] = useState(false);

  const toggleTheme = () => {
    setDarkMode(!darkMode);
    document.body.className = darkMode ? "light-mode" : "dark-mode";
  };

  return (
    <button onClick={toggleTheme}>
      Switch to {darkMode ? "Light" : "Dark"} Mode
    </button>
  );
};

export default Switcher;
