import React from "react";
import "../Home.css";

const Home = () => {
  return (
    <section className="home-section">
      <div className="home-container">
        <div className="home-content">
          <h1>Welcome to My Portfolio!</h1>
          <p>
            Hi, I'm <strong>Princess</strong>, a mom, a wife, and a budding
            software developer exploring the exciting world of coding. This
            portfolio showcases my journey, projects, and progress as I learn
            and grow.
          </p>
          <div className="home-buttons">
            <a href="about" className="btn">
              Learn More About Me
            </a>
          
            <a href="projects" className="btn">
              Explore My Projects
            </a>
          </div>
        </div>
        <div className="home-image">
          <img src="./img/Wrksp.avif" alt="Work" />
        </div>
      </div>
    </section>
  );
};

export default Home;
