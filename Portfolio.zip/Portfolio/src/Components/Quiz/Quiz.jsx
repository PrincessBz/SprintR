
import { useState } from "react";
import { Link } from "react-router-dom";
import "./Quiz.css";

const questions = [
  {
    question: "What is the capital of Nigeria?",
    options: ["Abuja", "Lagos", "Kano", "Port Harcourt"],
    answer: "Abuja",
  },
  {
    question: "Which language is primarily spoken in Nigeria?",
    options: ["French", "English", "Hausa", "Igbo"],
    answer: "English",
  },
  {
    question: "What is the currency of Nigeria?",
    options: ["Naira", "Dollar", "Pound", "Euro"],
    answer: "Naira",
  },
];

const Quiz = () => {
  const [userAnswers, setUserAnswers] = useState({});
  const [score, setScore] = useState(null);

  const handleOptionChange = (questionIndex, selectedOption) => {
    setUserAnswers({
      ...userAnswers,
      [questionIndex]: selectedOption,
    });
  };

  const handleSubmit = () => {
    let correctAnswers = 0;
    questions.forEach((question, index) => {
      if (userAnswers[index] === question.answer) {
        correctAnswers++;
      }
    });
    setScore(correctAnswers);
  };

  return (
    <div className="quiz-widget">
      <h2>Quiz</h2>
      {questions.map((question, index) => (
        <div key={index} className="question">
          <h3>{question.question}</h3>
          <div className="options">
            {question.options.map((option, i) => (
              <label key={i}>
                <input
                  type="radio"
                  name={`question-${index}`}
                  value={option}
                  onChange={() => handleOptionChange(index, option)}
                  checked={userAnswers[index] === option}
                />
                {option}
              </label>
            ))}
          </div>
        </div>
      ))}
      <button onClick={handleSubmit}>Submit</button>
      {score !== null && (
        <div className="result">
          <h3>
            Your Score: {score} / {questions.length}
          </h3>
        </div>
      )}
      {/* Button to go back to the home page */}
      <Link to="/">
        <button>Back to Home</button>
      </Link>
    </div>
  );
};

export default Quiz;
