import React from "react";
import "../About.css";
import { FaHeart, FaLaptopCode, FaGraduationCap } from "react-icons/fa";

const About = () => {
  return (
    <section className="about-section">
      <div className="about-container">
        <img
          src="./img/Mi.JPG" 
          alt="My portrait"
          className="about-photo"
        />
        <h1 className="about-header">About Me</h1>
        <p className="about-content">
          Hi! My name is <strong>Princess</strong>. I'm a{" "}
          <span className="highlight">mom</span>, a{" "}
          <span className="highlight">wife</span>, and a{" "}
          <span className="highlight">budding software developer</span> on an
          exciting learning journey.
          <br />
          <br />
          <FaHeart className="icon" /> Every day, I discover something new about
          software development, and my love for it continues to grow.
          <br />
          <br />
          <FaLaptopCode className="icon" /> This portfolio marks my first step
          into showcasing my work. I plan to refine and expand it as I progress
          in my studies and tackle larger projects.
          <br />
          <br />
          <FaGraduationCap className="icon" /> I'm currently in my second
          semester and excited to explore challenges and opportunities ahead.
          Thank you for joining me on this journey!
        </p>
      </div>
    </section>
  );
};

export default About;
