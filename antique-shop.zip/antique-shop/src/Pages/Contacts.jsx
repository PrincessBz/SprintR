import React from 'react'

const Contacts = () => {
  return (
  
      <p> Contact Us </p>
   
  );
}

export default Contacts