import React from "react";
import ProductList from "../Components/ProductList";


const Home = () => (
  <main>
    <h2>Antique Collection</h2>
    <ProductList />
  </main>
);

export default Home;
