import React from 'react'

const About = () => {
  return (
    <div className='about'>
      <h1>About Us</h1>
      <p>Welcome to **Antique Shop Naija **, your gateway to the rich heritage of Nigerian culture and craftmanship. Our collection celebrates the artistry and traditions of Nigeria, offering rare antiques and figurines that tell stories of a vibrant and diverse history.</p>
      <br />

      <p>Our journey began with deep love for the cultural artifacts of Nigeria-treasures that reflect the ingenuity, creativity, and spiritual depth of its people . From hand-carved figurines that echo ancestral wisdom to rare artifacts that embody the beauty of Nigeria's many ethnic groups, every item we curate is a testament to the skill and soul of its creator.</p>
      <br />
      <p>Thank you for joining us on this journey to celebrate Nigeria's legacy. Together, we honor the artistry of our ancestors and pass it forward to future generations.</p>
      <p style={{textAlign:"center" , fontFamily:"cursive", fontSize:"20px"}}>** The Antique Shop Naija Team **</p>
      </div>
  )
}

export default About