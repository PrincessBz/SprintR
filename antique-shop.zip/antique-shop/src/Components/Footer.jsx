
const Footer = () => {
  return (
    <footer className="footer">
      <div className="footer-content">
        <p>Princess &copy; 2024</p>
        <p>Follow us on:
          <a href="https://twitter.com" target="blank" rel="noopener noreferrer"> Twitter </a>
        </p>
      </div>
    </footer>
  );
};

export default Footer;
